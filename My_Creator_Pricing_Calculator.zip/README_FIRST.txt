MY CREATOR PRICING CALCULATOR

1. Extract the ZIP before opening the calculator.
2. Double click My_Creator_Pricing_Calculator.html.
3. Open it with Chrome, Edge, Firefox or Safari if asked.
4. Do not open the HTML file inside the ZIP preview.
5. To move your rates, expand Edit your base rates and estimated hours, then select Export settings.
6. Import the resulting creator-pricing-settings.json file on another device.

The calculator is standalone, works offline and does not depend on Copilot.
